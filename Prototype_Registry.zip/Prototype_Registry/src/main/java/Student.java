public class Student implements StudentClone<Student>{

    private long id;
    private String name;
    private double psp;
    private String batch;
    private int age;

    public Student(){}
    public Student(Student student){
        this.id = student.id;
        this.age = student.age;
        this.batch=student.batch;
        this.name = student.name;
        this.psp = student.psp;
    }
    @Override
    public Student clone() {
        return new Student(this);
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPsp() {
        return psp;
    }

    public void setPsp(double psp) {
        this.psp = psp;
    }

    public String getBatch() {
        return batch;
    }

    public void setBatch(String batch) {
        this.batch = batch;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
