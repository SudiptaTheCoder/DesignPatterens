

public class Client {
    private static void initRegistry(Registry registry){
        Student s1 = new Student();
        s1.setBatch("Dream 26 Student");

        IntelligentStudent s2 = new IntelligentStudent();
        s2.setBatch("Dream 26 Intelligent Student");

        registry.register("dream26Student",s1);
        registry.register("dream26IntelligentStudent",s2);

    }

    public static void main(String[] args){

        Registry registry = new Registry();
        initRegistry(registry);
        Student sumana = registry.get("dream26Student").clone();
        sumana.setName("Sumana Chanda");
        Student sudipta = registry.get("dream26IntelligentStudent").clone();
        sudipta.setName("Sudipta Chanda");
    }
}
