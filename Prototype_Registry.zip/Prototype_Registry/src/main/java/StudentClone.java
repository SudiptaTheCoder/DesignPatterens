public interface StudentClone <T>{
    T clone();
}
